from pymongo import MongoClient
from bson.objectid import ObjectId
import urllib.parse

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    #constructor to init the mongodb
    #to do: this should be a singleton
    def __init__(self, username, password):
        
        #URI must be percent escaped as per pymongo documentation
        
        username = urllib.parse.quote_plus('aacuser')
        password = urllib.parse.quote_plus('Allthese213!')
        
        self.client = MongoClient('mongodb://%s:%s@localhost:45176/?authSource=AAC' % (username, password))
        self.database = self.client['AAC']
        # Complete this create method to implement the C in CRUD
    
    def create(self, data):
        if data is not None:
            insert = self.database.animals.insert_one(data)  # data should be dictionary
            if insert!=0:
                return True
            else:
                return False    
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
            
            # Complete this create method to implement the R in CRUD

    def read(self, criteria=None):
        if criteria is not None:
            data = self.database.animals.find(criteria,{"_id": False})
           # for document in data:
              #  print(document)
            
        else:
            data = self.database.animals.find({},{"_id": False})
        
        return data
    
    # update function to implement the U in CRUD
    def update(self, first, change):
        if first is not None:
            if self.database.animals.count_documents(first, limit = 1) != 0:
                update_result = self.database.animals.update_many(first, {"$set": change})
                result = update_result.raw_result
            else:
                result = "No document was found!"
            return result
        else:
            raise Exception("Nothing to update, because data parameter is empty")
            
    # delete function to implement the D in CRUD
    def delete(self, remove):
        if remove is not None:
            if self.database.animals.count_documents(remove, limit = 1) != 0:
                delete_result = self.database.animals.delete_many(remove)
                result = delete_result.raw_result
            else:
                result = "No document was found!"
            return result
        else:
            raise Exception("Nothing to delete, because data parameter is empty")
